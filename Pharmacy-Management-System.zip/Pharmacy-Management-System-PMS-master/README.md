# PharmacyMangmentSystem
 A Pharmacy Mangment System That Manage Sales, Inventory and Automatic Medicine
