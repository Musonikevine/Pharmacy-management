<?php
session_start(); 

$key=$_SESSION['id'];

?>