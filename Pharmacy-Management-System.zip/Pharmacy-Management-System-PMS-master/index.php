<?php header("Location:http://healcura.irontin.com/u/login.php"); ?>

//Written By Abdul Fakhri