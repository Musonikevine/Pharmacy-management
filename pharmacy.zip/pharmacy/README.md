# spring-boot-user-registration-and-Login

What we have to build?

We have build two main functionalities:

Register user (stored data into MySQL database). 
Login Authentication - validate user login credentials with database email and password. 
We will secure the Registered Users Page with role-based Spring Security.

## Video

[![Rwanda Premier League](https://img.youtube.com/vi/VAHDI4dN8pQ/0.jpg)](https://youtu.be/VAHDI4dN8pQ)
